#!/usr/bin/env bash

conf=" -mining-address $CUSTOM_TEMPLATE -no-cpu -multi-gpu -stratum-password $CUSTOM_PASS"
[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

