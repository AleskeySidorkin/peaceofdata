#!/usr/bin/env bash

. h-manifest.conf

killall dynexsolve

sleep 21

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/hive/lib
./dynexsolve $(< $CUSTOM_CONFIG_FILENAME) 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log

